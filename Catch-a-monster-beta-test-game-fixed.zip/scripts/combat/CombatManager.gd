extends Node2D
## Main combat controller - horizontal defense + hunt/dungeon
## Player units fixed on right in 1-3 slots. Smart auto-battle.

signal wave_cleared(wave: int)
signal combat_ended(won: bool)

@onready var spawn_point: Marker2D = $SpawnPoint
@onready var player_spawn: Marker2D = $PlayerSpawn
@onready var castle: Area2D = $Castle
@onready var units_container: Node2D = $Units
@onready var hud: CanvasLayer = $HUD
@onready var catch_ui: Control = $HUD/CatchUI

var current_enemies: Array[Unit] = []
var player_units: Array[Unit] = []
var wave_timer: float = 0.0
var spawn_interval: float = 3.0
var enemies_to_spawn: int = 0
var enemies_spawned: int = 0
var is_spawning: bool = false
var is_boss_wave: bool = false
var target_for_catch: Dictionary = {}  # store data only after death
var unit_scene: PackedScene
var selected_unit_idx: int = 0  # which player unit receives manual skill
var gold_earned_this_run: int = 0
var monsters_caught_this_run: Array = []

# Slot Y offsets for 1-3 player units (relative to player_spawn)
const SLOT_OFFSETS := [0.0, -75.0, 75.0]

func _ready() -> void:
	unit_scene = preload("res://scenes/combat/Unit.tscn")
	GameManager.start_game()
	gold_earned_this_run = 0
	monsters_caught_this_run.clear()
	_setup_player_team()
	_connect_hud()
	if GameManager.current_mode == GameManager.GameMode.DUNGEON:
		GameManager.max_waves = 15
	elif GameManager.current_mode == GameManager.GameMode.HUNT:
		GameManager.max_waves = 8
	else:
		GameManager.max_waves = 10
	_start_next_wave()
	GameManager.game_over.connect(_on_game_over)
	GameManager.castle_hp_changed.connect(_on_castle_hp)
	GameManager.gold_changed.connect(_on_gold_changed)
	if castle and not castle.body_entered.is_connected(_on_castle_body_entered):
		castle.body_entered.connect(_on_castle_body_entered)
	AudioManager.play_bgm("combat")

func _setup_player_team() -> void:
	var team = GameManager.player_team
	if team.is_empty() and not GameManager.owned_monsters.is_empty():
		# Fallback: take first 3 owned
		for i in range(mini(3, GameManager.owned_monsters.size())):
			team.append(GameManager.owned_monsters[i])
		GameManager.player_team = team
	player_units.clear()
	for i in range(team.size()):
		if i >= 3:
			break
		var mdata = team[i]
		var u = unit_scene.instantiate() as Unit
		units_container.add_child(u)
		var y_off = SLOT_OFFSETS[i] if i < SLOT_OFFSETS.size() else (i - 1) * 70.0
		u.global_position = player_spawn.global_position + Vector2(0, y_off)
		u.setup(mdata, 0, i)  # 0 = Unit.Side.PLAYER (fix headless export enum bug)
		u.died.connect(_on_player_unit_died)
		player_units.append(u)
	_update_skill_labels()

func _connect_hud() -> void:
	if hud.has_node("SkillBar/Skill1"):
		hud.get_node("SkillBar/Skill1").pressed.connect(func(): _use_skill_manual(0))
	if hud.has_node("SkillBar/Skill2"):
		hud.get_node("SkillBar/Skill2").pressed.connect(func(): _use_skill_manual(1))
	if hud.has_node("SkillBar/Skill3"):
		hud.get_node("SkillBar/Skill3").pressed.connect(func(): _use_skill_manual(2))
	if hud.has_node("PauseBtn"):
		hud.get_node("PauseBtn").pressed.connect(_toggle_pause)
	if hud.has_node("AutoBtn"):
		hud.get_node("AutoBtn").pressed.connect(_toggle_auto)
	if hud.has_node("UnitSelect/Unit1"):
		hud.get_node("UnitSelect/Unit1").pressed.connect(func(): _select_unit(0))
	if hud.has_node("UnitSelect/Unit2"):
		hud.get_node("UnitSelect/Unit2").pressed.connect(func(): _select_unit(1))
	if hud.has_node("UnitSelect/Unit3"):
		hud.get_node("UnitSelect/Unit3").pressed.connect(func(): _select_unit(2))
	if catch_ui:
		catch_ui.visible = false
		if catch_ui.has_node("ThrowBasic"):
			catch_ui.get_node("ThrowBasic").pressed.connect(func(): _try_catch("basic"))
		if catch_ui.has_node("ThrowGreat"):
			catch_ui.get_node("ThrowGreat").pressed.connect(func(): _try_catch("great"))
		if catch_ui.has_node("ThrowUltra"):
			catch_ui.get_node("ThrowUltra").pressed.connect(func(): _try_catch("ultra"))
		if catch_ui.has_node("CancelCatch"):
			catch_ui.get_node("CancelCatch").pressed.connect(_cancel_catch)
	# Pause menu buttons
	if hud.has_node("PauseMenu/ResumeBtn"):
		hud.get_node("PauseMenu/ResumeBtn").pressed.connect(_resume_from_pause)
	if hud.has_node("PauseMenu/RestartBtn"):
		hud.get_node("PauseMenu/RestartBtn").pressed.connect(func(): SceneManager.go_combat())
	if hud.has_node("PauseMenu/QuitBtn"):
		hud.get_node("PauseMenu/QuitBtn").pressed.connect(func(): SceneManager.go_main_menu())

func _process(delta: float) -> void:
	if GameManager.current_state != GameManager.GameState.PLAYING:
		return
	if is_spawning and enemies_spawned < enemies_to_spawn:
		wave_timer -= delta
		if wave_timer <= 0:
			_spawn_enemy()
			wave_timer = spawn_interval
	# Check wave clear
	if not is_spawning and current_enemies.is_empty() and enemies_spawned >= enemies_to_spawn:
		_on_wave_cleared()
	# Smarter auto-battle: prefer ready skills on nearest units
	if GameManager.auto_battle and not player_units.is_empty():
		_auto_battle_tick()

func _auto_battle_tick() -> void:
	for u in player_units:
		if not u.is_alive:
			continue
		var idx = u.get_ready_skill_index()
		if idx >= 0:
			u.use_skill(idx)
			break  # one skill per frame to avoid spam

func _start_next_wave() -> void:
	GameManager.current_wave += 1
	GameManager.wave_changed.emit(GameManager.current_wave)
	current_enemies.clear()
	enemies_spawned = 0
	is_boss_wave = false
	var diff_mult = _difficulty_mult()
	if GameManager.current_mode == GameManager.GameMode.DUNGEON:
		if GameManager.current_wave == 5 or GameManager.current_wave == 10:
			is_boss_wave = true
			enemies_to_spawn = 1
			spawn_interval = 1.0
		elif GameManager.current_wave >= 15:
			is_boss_wave = true
			enemies_to_spawn = 1
		else:
			enemies_to_spawn = int((3 + GameManager.current_wave) * diff_mult)
			spawn_interval = max(1.0, 3.0 - GameManager.current_wave * 0.1)
	elif GameManager.current_mode == GameManager.GameMode.HUNT:
		enemies_to_spawn = 4 + GameManager.current_wave / 2
		spawn_interval = 2.4
	else:
		enemies_to_spawn = int((4 + GameManager.current_wave) * diff_mult)
		spawn_interval = max(1.3, 3.2 - GameManager.current_wave * 0.12)
	is_spawning = true
	wave_timer = 0.4
	_update_wave_label()

func _difficulty_mult() -> float:
	match GameManager.difficulty:
		"Easy": return 0.7
		"Hard": return 1.35
		"Nightmare": return 1.7
		_: return 1.0

func _spawn_enemy() -> void:
	var monster_id = _pick_enemy_id()
	var level = 1 + GameManager.current_wave / 2
	if is_boss_wave:
		if GameManager.current_wave >= 15:
			monster_id = "boss_inferno"
			level = 18 + GameManager.current_wave
		else:
			monster_id = "dragon_whelp"
			level = 8 + GameManager.current_wave
	var mdata = DataManager.create_monster_instance(monster_id, level)
	# Apply difficulty HP/ATK scale
	var mult = _difficulty_mult()
	mdata.max_hp = int(mdata.max_hp * mult)
	mdata.hp = mdata.max_hp
	mdata.atk = int(mdata.atk * (0.9 + mult * 0.15))
	var u = unit_scene.instantiate() as Unit
	units_container.add_child(u)
	u.global_position = spawn_point.global_position + Vector2(0, randf_range(-90, 90))
	u.setup(mdata, 1)  # 1 = Unit.Side.ENEMY (fix headless export enum bug)
	u.died.connect(_on_enemy_died)
	current_enemies.append(u)
	enemies_spawned += 1
	if enemies_spawned >= enemies_to_spawn:
		is_spawning = false

func _pick_enemy_id() -> String:
	if GameManager.current_mode == GameManager.GameMode.HUNT:
		var island = DataManager.islands.get(GameManager.selected_island, DataManager.islands.get("forest", {}))
		var pool = island.get("monsters", ["slime"])
		return pool[randi() % pool.size()]
	var pool = ["slime", "wolf", "bat", "golem"]
	if GameManager.current_wave > 4:
		pool.append("dragon_whelp")
	return pool[randi() % pool.size()]

func _on_enemy_died(unit: Unit) -> void:
	current_enemies.erase(unit)
	if GameManager.current_mode == GameManager.GameMode.HUNT and not unit.data.get("is_boss", false):
		_offer_catch(unit)

func _on_player_unit_died(unit: Unit) -> void:
	player_units.erase(unit)
	if player_units.is_empty():
		GameManager.game_over.emit(false)

func _on_wave_cleared() -> void:
	wave_cleared.emit(GameManager.current_wave)
	if GameManager.current_wave >= GameManager.max_waves:
		_victory()
	else:
		await get_tree().create_timer(1.4).timeout
		if GameManager.current_state == GameManager.GameState.PLAYING:
			_start_next_wave()

func _victory() -> void:
	var bonus = 80 * GameManager.current_wave
	match GameManager.difficulty:
		"Hard": bonus = int(bonus * 1.5)
		"Nightmare": bonus = int(bonus * 2.2)
	GameManager.add_gold(bonus)
	gold_earned_this_run += bonus
	if GameManager.current_mode == GameManager.GameMode.DUNGEON and GameManager.difficulty in ["Hard", "Nightmare"]:
		GameManager.inventory["boss_egg"] = GameManager.inventory.get("boss_egg", 0) + 1
	SaveManager.save_game()
	combat_ended.emit(true)
	_show_result(true)

func _on_game_over(won: bool) -> void:
	if not won:
		_show_result(false)

func _show_result(won: bool) -> void:
	GameManager.current_state = GameManager.GameState.RESULT
	AudioManager.stop_bgm()
	if hud.has_node("ResultPanel"):
		var panel = hud.get_node("ResultPanel")
		panel.visible = true
		if panel.has_node("ResultLabel"):
			panel.get_node("ResultLabel").text = "VICTORY!" if won else "DEFEAT..."
		if panel.has_node("DetailLabel"):
			var detail = "Gold earned: ~%d\nCaught: %d" % [gold_earned_this_run, monsters_caught_this_run.size()]
			if won and GameManager.current_mode == GameManager.GameMode.DUNGEON and GameManager.difficulty in ["Hard", "Nightmare"]:
				detail += "\nBoss Egg obtained!"
			panel.get_node("DetailLabel").text = detail
		if panel.has_node("RetryBtn"):
			var btn = panel.get_node("RetryBtn")
			if not btn.pressed.is_connected(_on_retry):
				btn.pressed.connect(_on_retry)
		if panel.has_node("MenuBtn"):
			var btn2 = panel.get_node("MenuBtn")
			if not btn2.pressed.is_connected(_on_menu):
				btn2.pressed.connect(_on_menu)

func _on_retry() -> void:
	SceneManager.go_combat()

func _on_menu() -> void:
	SceneManager.go_main_menu()

func _select_unit(idx: int) -> void:
	if idx < player_units.size() and player_units[idx].is_alive:
		selected_unit_idx = idx
		_update_skill_labels()

func _use_skill_manual(skill_idx: int) -> void:
	if player_units.is_empty():
		return
	var chosen: Unit = null
	if selected_unit_idx < player_units.size() and player_units[selected_unit_idx].is_alive:
		chosen = player_units[selected_unit_idx]
	else:
		chosen = _find_best_unit_for_skill()
	if chosen:
		chosen.use_skill(skill_idx)
		_update_skill_labels()

func _find_best_unit_for_skill() -> Unit:
	var best: Unit = null
	var best_dist := INF
	for u in player_units:
		if not u.is_alive:
			continue
		var nearest = u._find_nearest_opponent()
		if nearest:
			var d = u.global_position.distance_to(nearest.global_position)
			if d < best_dist:
				best_dist = d
				best = u
	if best == null:
		for u in player_units:
			if u.is_alive:
				return u
	return best

func _update_skill_labels() -> void:
	if player_units.is_empty():
		return
	var u = player_units[selected_unit_idx] if selected_unit_idx < player_units.size() else player_units[0]
	if not u or not u.is_alive:
		return
	var skills = u.data.get("skills", [])
	for i in range(3):
		var btn_path = "SkillBar/Skill%d" % (i + 1)
		if hud.has_node(btn_path):
			var btn = hud.get_node(btn_path)
			if i < skills.size():
				var sk = DataManager.get_skill(skills[i])
				var cd = u.skill_cooldowns.get(skills[i], 0.0)
				btn.text = sk.get("name", "Skill") if cd <= 0 else "%.1fs" % cd
				btn.disabled = cd > 0
			else:
				btn.text = "-"
				btn.disabled = true

func _toggle_pause() -> void:
	if GameManager.current_state == GameManager.GameState.PLAYING:
		GameManager.pause_game()
		if hud.has_node("PauseMenu"):
			hud.get_node("PauseMenu").visible = true
	else:
		_resume_from_pause()

func _resume_from_pause() -> void:
	GameManager.resume_game()
	if hud.has_node("PauseMenu"):
		hud.get_node("PauseMenu").visible = false

func _toggle_auto() -> void:
	GameManager.auto_battle = not GameManager.auto_battle
	if hud.has_node("AutoBtn"):
		hud.get_node("AutoBtn").text = "AUTO: ON" if GameManager.auto_battle else "AUTO: OFF"

func _offer_catch(unit: Unit) -> void:
	target_for_catch = unit.data.duplicate(true)
	target_for_catch["last_hp"] = unit.hp
	target_for_catch["last_max_hp"] = unit.max_hp
	target_for_catch["last_level"] = unit.level
	if catch_ui:
		catch_ui.visible = true
		if catch_ui.has_node("InfoLabel"):
			var hp_ratio = float(unit.hp) / max(1, unit.max_hp)
			catch_ui.get_node("InfoLabel").text = "%s (HP %.0f%%)\nChoose Ball" % [unit.data.get("name", "?"), hp_ratio * 100]
		_update_ball_buttons()

func _update_ball_buttons() -> void:
	for bid in ["basic", "great", "ultra"]:
		var node_name = "Throw" + bid.capitalize()
		if catch_ui and catch_ui.has_node(node_name):
			var btn = catch_ui.get_node(node_name)
			var count = GameManager.balls.get(bid, 0)
			btn.text = "%s (%d)" % [bid.capitalize(), count]
			btn.disabled = count <= 0

func _try_catch(ball_id: String) -> void:
	if target_for_catch.is_empty() or GameManager.balls.get(ball_id, 0) <= 0:
		return
	GameManager.balls[ball_id] -= 1
	var hp_ratio = float(target_for_catch.get("last_hp", 1)) / max(1, target_for_catch.get("last_max_hp", 1))
	var rate = DataManager.calc_catch_rate(target_for_catch, ball_id, hp_ratio)
	var success = randf() < rate
	_play_catch_fx(success)
	if success:
		var new_mon = DataManager.create_monster_instance(target_for_catch.id, target_for_catch.get("last_level", 1))
		GameManager.add_owned_monster(new_mon)
		monsters_caught_this_run.append(new_mon)
		if catch_ui.has_node("InfoLabel"):
			catch_ui.get_node("InfoLabel").text = "SUCCESS! Caught " + new_mon.name
		AudioManager.play_sfx("catch_success")
	else:
		if catch_ui.has_node("InfoLabel"):
			catch_ui.get_node("InfoLabel").text = "Failed... Ball broke!"
		AudioManager.play_sfx("catch_fail")
	await get_tree().create_timer(1.3).timeout
	_cancel_catch()
	SaveManager.save_game()

func _play_catch_fx(success: bool) -> void:
	if catch_ui:
		var tween = create_tween()
		var col = Color(0.3, 1.0, 0.4) if success else Color(1.0, 0.3, 0.3)
		tween.tween_property(catch_ui, "modulate", col, 0.15)
		tween.tween_property(catch_ui, "modulate", Color.WHITE, 0.3)

func _cancel_catch() -> void:
	target_for_catch = {}
	if catch_ui:
		catch_ui.visible = false

func _on_castle_hp(cur: int, mx: int) -> void:
	if hud.has_node("CastleHPBar"):
		hud.get_node("CastleHPBar").max_value = mx
		hud.get_node("CastleHPBar").value = cur
	if hud.has_node("CastleHPLabel"):
		hud.get_node("CastleHPLabel").text = "Castle %d/%d" % [cur, mx]

func _on_gold_changed(g: int) -> void:
	if hud.has_node("GoldLabel"):
		hud.get_node("GoldLabel").text = "Gold: %d" % g

func _update_wave_label() -> void:
	if hud.has_node("WaveLabel"):
		var extra = " [BOSS]" if is_boss_wave else ""
		hud.get_node("WaveLabel").text = "Wave %d / %d%s" % [GameManager.current_wave, GameManager.max_waves, extra]

func _on_castle_body_entered(body: Node2D) -> void:
	if body is Unit and body.side == Unit.Side.ENEMY and body.is_alive:
		var dmg = 20 + body.level * 3
		GameManager.damage_castle(dmg)
		body.take_damage(99999)
